package com.example.it140pobe

data class Ingredient(
    val name: String,
    val imageRes: Int,
    val price: Int
)