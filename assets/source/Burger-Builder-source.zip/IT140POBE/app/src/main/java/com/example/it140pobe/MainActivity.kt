package com.example.it140pobe

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var burgerStack: LinearLayout
    private lateinit var tvPrice: TextView
    private var totalPrice = 250 // Encapsulated State

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        burgerStack = findViewById(R.id.burgerStack)
        tvPrice = findViewById(R.id.tvPrice)
        val tray = findViewById<RecyclerView>(R.id.inventoryTray)

        val ingredients = listOf(
            Ingredient("Cheese", R.drawable.cheese, 20),
            Ingredient("Patty", R.drawable.patty, 50),
            Ingredient("Onion", R.drawable.onion, 15)
        )

        tray.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        tray.adapter = InventoryAdapter(ingredients) { selected ->
            addIngredientToBurger(selected)
        }
        val btnReset = findViewById<Button>(R.id.btnReset)
        btnReset.setOnClickListener {
            resetBurger()
        }
    }

    private fun addIngredientToBurger(item: BurgerComponent) {
        val layer = ImageView(this).apply {
            setImageResource(item.imageRes)
            layoutParams = LinearLayout.LayoutParams(400, 130).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = -60 // Creates the layered effect
            }
        }

        // Always adds between the buns (Index 1)
        burgerStack.addView(layer, 1)

        totalPrice += item.getPrice()
        tvPrice.text = "$$totalPrice"
    }

    private fun resetBurger() {
        // 1. Reset the Data State
        totalPrice = 250
        tvPrice.text = "$$totalPrice"

        // 2. Clear the UI Stack
        // We keep index 0 (Top Bun) and the last index (Bottom Bun)
        // We remove everything in between
        val childCount = burgerStack.childCount
        if (childCount > 2) {
            // We remove views from index 1 up to the one before the last
            // Doing it in reverse prevents index skipping errors
            for (i in (childCount - 2) downTo 1) {
                burgerStack.removeViewAt(i)
            }
        }

        Toast.makeText(this, "Burger Reset!", Toast.LENGTH_SHORT).show()
    }
}