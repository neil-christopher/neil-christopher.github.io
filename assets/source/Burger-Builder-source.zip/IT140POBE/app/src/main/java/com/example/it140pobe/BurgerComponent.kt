package com.example.it140pobe

interface Priceable {
    fun getPrice(): Int
}

// Base Class (OOP: Abstraction/Inheritance)
abstract class BurgerComponent(
    val name: String,
    val imageRes: Int
) : Priceable

// Subclass for actual ingredients
class Ingredient(
    name: String,
    imageRes: Int,
    private val price: Int
) : BurgerComponent(name, imageRes) {
    override fun getPrice(): Int = price
}