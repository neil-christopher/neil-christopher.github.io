package com.example.it140pobe

import android.view.*
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val items: List<BurgerComponent>,
    private val onAdd: (BurgerComponent) -> Unit
) : RecyclerView.Adapter<InventoryAdapter.IngredientViewHolder>() {

    class IngredientViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.itemImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IngredientViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_ingredient, parent, false)
        return IngredientViewHolder(v)
    }

    override fun onBindViewHolder(holder: IngredientViewHolder, position: Int) {
        val item = items[position]
        holder.img.setImageResource(item.imageRes)
        holder.itemView.setOnClickListener { onAdd(item) }
    }

    override fun getItemCount() = items.size
}