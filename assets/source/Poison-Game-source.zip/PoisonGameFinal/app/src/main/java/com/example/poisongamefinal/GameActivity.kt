package com.example.poisongamefinal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class GameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val player1Name = intent.getStringExtra("player1") ?: "Player 1"
        val player2Name = intent.getStringExtra("player2") ?: "Player 2"

        setContent {
            PoisonGameScreen(player1Name, player2Name)
        }
    }
}

data class Card(val index: Int, var isPoison: Boolean = false, var isFlipped: Boolean = false)
data class Player(val name: String, var score: Int = 0, var isAlive: Boolean = true)

data class GameState(
    val grid: List<Card>,
    val player1: Player,
    val player2: Player,
    val turn: Int,
    val poisonsChosen: Int,
    val gameOver: Boolean
)

@Composable
fun PoisonGameScreen(player1Name: String, player2Name: String) {
    var gameState by remember {
        mutableStateOf(
            GameState(
                grid = List(16) { Card(it) },
                player1 = Player(player1Name),
                player2 = Player(player2Name),
                turn = 1,
                poisonsChosen = 0,
                gameOver = false
            )
        )
    }

    fun resetGame() {
        gameState = GameState(
            grid = List(16) { Card(it) },
            player1 = Player(player1Name),
            player2 = Player(player2Name),
            turn = 1,
            poisonsChosen = 0,
            gameOver = false
        )
    }

    fun handleCardClick(card: Card) {
        if (gameState.gameOver || card.isFlipped || gameState.poisonsChosen < 2) return

        val currentPlayer = if (gameState.turn == 1) gameState.player1 else gameState.player2
        if (!currentPlayer.isAlive) return

        val newGrid = gameState.grid.toMutableList()
        val selected = newGrid[card.index]

        selected.isFlipped = true
        if (selected.isPoison) currentPlayer.isAlive = false else currentPlayer.score++
        gameState = gameState.copy(
            grid = newGrid,
            player1 = if (gameState.turn == 1) currentPlayer else gameState.player1,
            player2 = if (gameState.turn == 2) currentPlayer else gameState.player2,
            turn = if (gameState.turn == 1) 2 else 1,
            gameOver = (!gameState.player1.isAlive || !gameState.player2.isAlive || newGrid.all { it.isFlipped })
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("${gameState.player1.name}: ${gameState.player1.score} ${if (!gameState.player1.isAlive) "(DEAD)" else ""}", fontSize = 18.sp)
        Text("${gameState.player2.name}: ${gameState.player2.score} ${if (!gameState.player2.isAlive) "(DEAD)" else ""}", fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))

        GridComposable(
            grid = gameState.grid,
            onCardClick = { card ->
                if (gameState.poisonsChosen < 2 && !card.isPoison) {
                    val newGrid = gameState.grid.toMutableList()
                    newGrid[card.index] = card.copy(isPoison = true)
                    gameState = gameState.copy(grid = newGrid, poisonsChosen = gameState.poisonsChosen + 1)
                } else {
                    handleCardClick(card)
                }
            },
            revealAll = gameState.gameOver,
            modifier = Modifier.weight(1f)
        )

        if (gameState.gameOver) {
            val winner = when {
                gameState.player1.score > gameState.player2.score -> gameState.player1.name
                gameState.player2.score > gameState.player1.score -> gameState.player2.name
                else -> "Draw"
            }
            GameOverDialog(winner, onRestart = { resetGame() })
        }
    }
}


@Composable
fun GridComposable(
    grid: List<Card>,
    onCardClick: (Card) -> Unit,
    revealAll: Boolean = false,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        items(grid.size) { index ->
            val card = grid[index]
            val color = when {
                revealAll || card.isFlipped -> if (card.isPoison) Color.Red else Color.Green
                else -> Color.Gray
            }
            Box(
                modifier = Modifier
                    .padding(4.dp)
                    .aspectRatio(1f)
                    .background(color)
                    .clickable(enabled = true) {
                        onCardClick(card)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when {
                        revealAll || card.isFlipped -> if (card.isPoison) "☠️" else "🍭"
                        else -> "❓"
                    },
                    fontSize = 24.sp
                )
            }
        }
    }
}


@Composable
fun GameOverDialog(winner: String, onRestart: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Game Over") },
        text = { Text(if (winner == "Draw") "It's a Draw!" else "Winner: $winner") },
        confirmButton = {
            Button(onClick = onRestart) {
                Text("Restart Game")
            }
        }
    )
}

