package com.example.poisongamefinal

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreen { p1, p2 ->
                val intent = Intent(this, GameActivity::class.java).apply {
                    putExtra("player1", p1)
                    putExtra("player2", p2)
                }
                startActivity(intent)
            }
        }
    }
}

@Composable
fun LoginScreen(onStartGame: (String, String) -> Unit) {
    var player1 by remember { mutableStateOf("") }
    var player2 by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Enter Player Names", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(value = player1, onValueChange = { player1 = it }, label = { Text("Player 1") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = player2, onValueChange = { player2 = it }, label = { Text("Player 2") })
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onStartGame(player1, player2) },
            enabled = player1.isNotBlank() && player2.isNotBlank()
        ) {
            Text("Start Game")
        }
    }
}