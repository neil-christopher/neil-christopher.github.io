package com.example.poisongamefinal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class GameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val player1Name = intent.getStringExtra("player1") ?: "Player 1"
        val player2Name = intent.getStringExtra("player2") ?: "Player 2"

        setContent {
            PoisonGameScreen(player1Name, player2Name)
        }
    }
}

data class Card(val index: Int, var isPoison: Boolean = false, var isFlipped: Boolean = false)
data class Player(val name: String, var score: Int = 0, var isAlive: Boolean = true)

@Composable
fun PoisonGameScreen(player1Name: String, player2Name: String) {
    var grid by remember { mutableStateOf(List(16) { Card(it) }) }
    var player1 by remember { mutableStateOf(Player(player1Name)) }
    var player2 by remember { mutableStateOf(Player(player2Name)) }
    var turn by remember { mutableStateOf(1) }
    var poisonsChosen by remember { mutableStateOf(0) }
    var gameOver by remember { mutableStateOf(false) }

    fun handleCardClick(card: Card) {
        if (gameOver || card.isFlipped || poisonsChosen < 2) return

        val currentPlayer = if (turn == 1) player1 else player2
        if (!currentPlayer.isAlive) return

        val newGrid = grid.toMutableList()
        val selected = newGrid[card.index]

        selected.isFlipped = true
        if (selected.isPoison) currentPlayer.isAlive = false else currentPlayer.score++
        grid = newGrid
        turn = if (turn == 1) 2 else 1

        if (!player1.isAlive || !player2.isAlive || grid.all { it.isFlipped }) {
            gameOver = true
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("${player1.name}: ${player1.score} ${if (!player1.isAlive) "(DEAD)" else ""}", fontSize = 18.sp)
        Text("${player2.name}: ${player2.score} ${if (!player2.isAlive) "(DEAD)" else ""}", fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))

        GridComposable(
            grid = grid,
            onCardClick = { card ->
                if (poisonsChosen < 2 && !card.isPoison) {
                    val newGrid = grid.toMutableList()
                    newGrid[card.index].isPoison = true
                    grid = newGrid
                    poisonsChosen++
                } else {
                    handleCardClick(card)
                }
            },
            revealAll = gameOver
        )

        if (gameOver) {
            val winner = when {
                player1.score > player2.score -> player1.name
                player2.score > player1.score -> player2.name
                else -> "Draw"
            }
            GameOverDialog(winner)
        }
    }
}

@Composable
fun GridComposable(grid: List<Card>, onCardClick: (Card) -> Unit, revealAll: Boolean = false) {
    LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.height(360.dp)) {
        items(grid.size) { index ->
            val card = grid[index]
            val color = when {
                revealAll || card.isFlipped -> if (card.isPoison) Color.Red else Color.Green
                else -> Color.Gray
            }
            Box(
                modifier = Modifier
                    .padding(4.dp)
                    .size(80.dp)
                    .background(color)
                    .clickable { onCardClick(card) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when {
                        revealAll || card.isFlipped -> if (card.isPoison) "☠️" else "🍬"
                        else -> "❓"
                    },
                    fontSize = 24.sp
                )
            }
        }
    }
}

@Composable
fun GameOverDialog(winner: String) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Game Over") },
        text = { Text(if (winner == "Draw") "It's a Draw!" else "Winner: $winner") },
        confirmButton = {
            Button(onClick = {}) {
                Text("OK")
            }
        }
    )
}
