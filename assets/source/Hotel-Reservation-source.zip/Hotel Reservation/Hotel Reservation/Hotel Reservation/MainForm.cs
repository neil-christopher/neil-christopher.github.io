﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Reservation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Book_a_Room book_A_Room = new Book_a_Room();
            book_A_Room.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Check_Out check_out = new Check_Out();
            check_out.Show();
        }

        
        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
