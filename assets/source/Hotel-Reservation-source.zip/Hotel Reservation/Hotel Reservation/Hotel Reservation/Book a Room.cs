﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hotel_Reservation
{
    public partial class Book_a_Room : Form
    {
        private bool ascendingOrder = true;

        public Dictionary<string, List<string>> reservationDict = new Dictionary<string, List<string>>();

        public const string fileLoc = "C:\\Users\\Neil\\source\\repos\\Hotel Reservation\\";

        public const string dateFormat = "MM/dd/yyyy";

        public const string hotelName = "HTL";

        public Book_a_Room()
        {
            InitializeComponent();
            Initialize_Dictionary();

            checkIn_DTP.Value = DateTime.Now;
            checkOut_DTP.Value = DateTime.Now;

            reservationData_LV.View = View.Details;

            reservationData_LV.Columns.Add("First Name", 70);
            reservationData_LV.Columns.Add("Last Name", 70);
            reservationData_LV.Columns.Add("Phone", 80);
            reservationData_LV.Columns.Add("Email", 150);
            reservationData_LV.Columns.Add("Room Type", 70);
            reservationData_LV.Columns.Add("Check In", 80);
            reservationData_LV.Columns.Add("Check Out", 80);
            reservationData_LV.Columns.Add("Adult/s", 60);
            reservationData_LV.Columns.Add("Children", 60);
            reservationData_LV.Columns.Add("Special Requests", 100);
            reservationData_LV.Columns.Add("Reference No.", 150);

            Initialize_ListView();
        }

        public void Initialize_Dictionary()
        {
            using (StreamReader sr = new StreamReader(fileLoc + "Reservations.txt", true))
            {
                string line;

                while ((line = sr.ReadLine()) != null)
                {
                    string[] parts = line.Split(';');

                    List<string> Templist = new List<string>();

                    Templist.Add(parts[0]); 
                    Templist.Add(parts[1]);
                    Templist.Add(parts[2]);
                    Templist.Add(parts[3]);
                    Templist.Add(parts[4]);
                    Templist.Add(parts[5]);
                    Templist.Add(parts[6]);
                    Templist.Add(parts[7]);
                    Templist.Add(parts[8]);
                    Templist.Add(parts[9]);
                    Templist.Add(parts[10]);

                    reservationDict.Add(parts[10], Templist);
                }
            }
        }
        public void Initialize_ListView()
        {
            reservationData_LV.Items.Clear();

            foreach (var line_dic in reservationDict)
            {
                string key = line_dic.Key;

                List<string> values = line_dic.Value;

                string[] row = { values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8], values[9], values[10] };

                ListViewItem listItem = new ListViewItem(values[0]);

                foreach (var value in row)
                {
                    listItem.SubItems.Add(value);
                }

                reservationData_LV.Items.Add(listItem);
            }
        }

        public string generate_RefNo()
        {
            Random rnd = new Random();

            bool exit = true;
            string referenceNo = "";

            while (exit)
            {
                bool isFound = false;

                int uniqueIdentifier = rnd.Next(10000, 99999);
                referenceNo = $"{hotelName}-{checkIn_DTP.Value.ToString("yyyy")}{checkIn_DTP.Value.ToString("MM")}{checkIn_DTP.Value.ToString("dd")}-{uniqueIdentifier}";

                foreach (var dic in reservationDict)
                {
                    if (referenceNo == dic.Key)
                    {
                        isFound = true;
                        break;
                    }
                }

                if (isFound)
                {
                    continue;
                }
                else
                {
                    exit = false;
                }
            }

            return referenceNo;
        }

        public void clear_InputField()
        {
            addBooking.Enabled = true;

            First_TB.Enabled = true;
            First_TB.Text = "First";
            First_TB.ForeColor = Color.Gray;

            Last_TB.Enabled = true;
            Last_TB.Text = "Last";
            Last_TB.ForeColor = Color.Gray;

            Phone_TB.Enabled = true;
            Phone_TB.Text = "+63";
            Phone_TB.ForeColor = Color.Gray;

            Email_TB.Enabled = true;
            Email_TB.Text = "E-mail address";
            Email_TB.ForeColor = Color.Gray;

            checkIn_DTP.Value = DateTime.Now;
            checkOut_DTP.Value = DateTime.Now;

            RoomType_CB1.Text = "Select Room Type";

            Adult_TB.Text = "# of Adults";
            Adult_TB.ForeColor = Color.Gray;

            children_TB.Text = "# of Children";
            children_TB.ForeColor = Color.Gray;

            SR_TB.Text = "None";
            SR_TB.ForeColor = Color.Gray;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm form1 = new MainForm();
            form1.Show();
        }

        private void fname_Enter(object sender, EventArgs e)
        {
            if (First_TB.Text == "First")
            {
                First_TB.Text = "";
                First_TB.ForeColor = Color.Black;
            }
        }

        private void fname_Leave(object sender, EventArgs e)
        {
            if (First_TB.Text == "")
            {
                First_TB.Text = "First";
                First_TB.ForeColor = Color.Gray;
            }
        }

        private void lname_Enter(object sender, EventArgs e)
        {
            if (Last_TB.Text == "Last")
            {
                Last_TB.Text = "";
                Last_TB.ForeColor = Color.Black;
            }
        }

        private void lname_Leave(object sender, EventArgs e)
        {
            if (Last_TB.Text == "")
            {
                Last_TB.Text = "Last";
                Last_TB.ForeColor = Color.Gray;
            }
        }

        private void pnum_Enter(object sender, EventArgs e)
        {
            if (Phone_TB.Text == "+63")
            {
                Phone_TB.Text = "";
                Phone_TB.ForeColor = Color.Black;
            }
        }

        private void pnum_Leave(object sender, EventArgs e)
        {
            if (Phone_TB.Text == "")
            {
                Phone_TB.Text = "+63";
                Phone_TB.ForeColor = Color.Silver;
            }
        }

        private void email_Enter(object sender, EventArgs e)
        {
            if (Email_TB.Text == "E-mail address")
            {
                Email_TB.Text = "";
                Email_TB.ForeColor = Color.Black;
            }
        }

        private void email_Leave(object sender, EventArgs e)
        {
            if (Email_TB.Text == "")
            {
                Email_TB.Text = "E-mail address";
                Email_TB.ForeColor = Color.Gray;
            }
        }

        private void anum_Enter(object sender, EventArgs e)
        {
            if (Adult_TB.Text == "# of Adults")
            {
                Adult_TB.Text = "";
                Adult_TB.ForeColor = Color.Black;
            }
        }

        private void anum_Leave(object sender, EventArgs e)
        {

            if (Adult_TB.Text == "")
            {
                Adult_TB.Text = "# of Adults";
                Adult_TB.ForeColor = Color.Gray;
            }
        }

        private void cnum_Enter(object sender, EventArgs e)
        {
            if (children_TB.Text == "# of Children")
            {
                children_TB.Text = "";
                children_TB.ForeColor = Color.Black;
            }
        }

        private void cnum_Leave(object sender, EventArgs e)
        {
            if (children_TB.Text == "")
            {
                children_TB.Text = "# of Children";
                children_TB.ForeColor = Color.Gray;
            }
        }

        private void sr_Enter(object sender, EventArgs e)
        {
            if (SR_TB.Text == "None")
            {
                SR_TB.Text = "";
                SR_TB.ForeColor = Color.Black;
            }
        }

        private void sr_Leave(object sender, EventArgs e)
        {
            if (SR_TB.Text == "")
            {
                SR_TB.Text = "None";
                SR_TB.ForeColor = Color.Gray;
            }
        }

        private void ro_Enter(object sender, EventArgs e)
        {
            if (searchRef_TB.Text == "Enter Reference No.")
            {
                searchRef_TB.Text = "";
                searchRef_TB.ForeColor = Color.Black;
            }
        }

        private void ro_Leave(object sender, EventArgs e)
        {
            if (searchRef_TB.Text == "")
            {
                searchRef_TB.Text = "Enter Reference No.";
                searchRef_TB.ForeColor = Color.Gray;
            }
        }

        private void Submit_Click(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void reservationData_LV_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (reservationData_LV.SelectedItems.Count > 0)
            {
                addBooking.Enabled = false;

                ListViewItem selectedItem = reservationData_LV.SelectedItems[0];
                
                First_TB.Text = selectedItem.SubItems[0].Text; // First Name
                First_TB.Enabled = false;
                First_TB.ForeColor = Color.Black;

                Last_TB.Text = selectedItem.SubItems[1].Text;  // Last Name
                Last_TB.Enabled = false;
                Last_TB.ForeColor = Color.Black;

                Phone_TB.Text = selectedItem.SubItems[2].Text; // Phone
                Phone_TB.Enabled = false;
                Phone_TB.ForeColor = Color.Black;

                Email_TB.Text = selectedItem.SubItems[3].Text; // Email
                Email_TB.Enabled = false;
                Email_TB.ForeColor = Color.Black;

                RoomType_CB1.SelectedItem = selectedItem.SubItems[4].Text; //Room Type
                RoomType_CB1.ForeColor = Color.Black;

                string inVal = selectedItem.SubItems[5].Text;
                string outVal = selectedItem.SubItems[6].Text;

                DateTime parsed_inDate;
                DateTime parsed_OutDate;

                if (DateTime.TryParseExact(inVal, dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out parsed_inDate)){

                    checkIn_DTP.Value = parsed_inDate;  // Check-In
                }

                if (DateTime.TryParseExact(outVal, dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out parsed_OutDate))
                {

                    checkOut_DTP.Value = parsed_OutDate;  // Check-In
                }
                
                Adult_TB.Text = selectedItem.SubItems[7].Text; // Number of Adults
                Adult_TB.ForeColor = Color.Black;

                children_TB.Text = selectedItem.SubItems[8].Text; // Number of Children
                children_TB.ForeColor = Color.Black;

                SR_TB.Text = selectedItem.SubItems[9].Text;  // Special Request
                SR_TB.ForeColor = Color.Black;

                refNo_TB.Text = selectedItem.SubItems[10].Text;
                SR_TB.ForeColor = Color.Gray;
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (First_TB.Text.Length > 0 && Last_TB.Text.Length > 0 && Phone_TB.Text.Length > 0 && Email_TB.Text.Length > 0 && Phone_TB.Text.Length > 0 && Adult_TB.Text.Length > 0 && children_TB.Text.Length > 0)
            {
                if (Phone_TB.Text.Length == 11)
                {
                    if (checkIn_DTP.Value >= DateTime.Now && checkOut_DTP.Value >= DateTime.Now)
                    {
                        if (RoomType_CB1.Text != "Select Room Type")
                        {
                            List<string> tempList = new List<string>();

                            string refNo = generate_RefNo();

                            tempList.Add(First_TB.Text);
                            tempList.Add(Last_TB.Text);
                            tempList.Add(Phone_TB.Text);
                            tempList.Add(Email_TB.Text);
                            tempList.Add(RoomType_CB1.Text);
                            tempList.Add(Convert.ToString(checkIn_DTP.Value));
                            tempList.Add(Convert.ToString(checkOut_DTP.Value));
                            tempList.Add(Adult_TB.Text);
                            tempList.Add(children_TB.Text);
                            tempList.Add(SR_TB.Text);
                            tempList.Add(refNo);

                            reservationDict.Add(Last_TB.Text, tempList);

                            using (StreamWriter sw = new StreamWriter(fileLoc + "Reservations.txt", true))
                            {
                                sw.WriteLine($"{First_TB.Text};{Last_TB.Text};{Phone_TB.Text};{Email_TB.Text};{RoomType_CB1.Text};{checkIn_DTP.Value.ToString(dateFormat)};{checkOut_DTP.Value.ToString(dateFormat)};{Adult_TB.Text};{children_TB.Text};{SR_TB.Text};{refNo}");
                            }

                            Initialize_ListView();

                            MessageBox.Show($"Reservation for {First_TB.Text} {Last_TB.Text} has been added!");
                        }
                        else
                        {
                            MessageBox.Show("Please Select Room Type");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Date");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Phone no.");
                }
            }
            else
            {
                MessageBox.Show("Input fields should be filled!");
            }
        }

        private void updateBooking_Click(object sender, EventArgs e)
        {
            List<string> updatedList = new List<string>() { First_TB.Text, Last_TB.Text, Phone_TB.Text, Email_TB.Text, RoomType_CB1.Text, Convert.ToString(checkIn_DTP.Value.ToString(dateFormat)), Convert.ToString(checkOut_DTP.Value.ToString(dateFormat)), Adult_TB.Text, children_TB.Text, SR_TB.Text, refNo_TB.Text };
            reservationDict[refNo_TB.Text].Clear();
            reservationDict[refNo_TB.Text] = updatedList;

            Initialize_ListView();

            MessageBox.Show($"Reservation of {First_TB.Text} {Last_TB.Text} has been updated!");
        }

        private void newBooking_Click(object sender, EventArgs e)
        {
            clear_InputField();
        }

        private void removeBooking_Click(object sender, EventArgs e)
        {
            reservationDict.Remove(Phone_TB.Text);
            Initialize_ListView();
            clear_InputField();
            MessageBox.Show($"Reservation of {First_TB.Text} {Last_TB.Text} has been removed!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool isFound = false;

            if (searchRef_TB.Text.Length > 0)
            {
                foreach (var dic in reservationDict)
                {
                    if (searchRef_TB.Text == dic.Key)
                    {
                        First_TB.Text = dic.Value[0];
                        Last_TB.Text = dic.Value[1];
                        Phone_TB.Text = dic.Value[2];
                        Email_TB.Text = dic.Value[3];
                        RoomType_CB1.SelectedItem = dic.Value[4];
                        Adult_TB.Text = dic.Value[7];
                        children_TB.Text = dic.Value[8];
                        SR_TB.Text = dic.Value[9];
                        refNo_TB.Text = dic.Key;

                        string inVal = dic.Value[5];
                        string outVal = dic.Value[6];

                        DateTime parsed_inDate;
                        DateTime parsed_OutDate;

                        if (DateTime.TryParseExact(inVal, dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out parsed_inDate))
                        {

                            checkIn_DTP.Value = parsed_inDate;  // Check-In
                        }

                        if (DateTime.TryParseExact(outVal, dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out parsed_OutDate))
                        {

                            checkOut_DTP.Value = parsed_OutDate;  // Check-In
                        }

                        isFound = true;
                        break;
                    }
                }

                if (!isFound)
                {
                    MessageBox.Show("Reference No. not found!");
                }
            }
        }
        public class ListViewItemComparer : System.Collections.IComparer
        {
            private int columnIndex;
            private bool ascendingOrder;

            public ListViewItemComparer(int columnIndex, bool ascendingOrder)
            {
                this.columnIndex = columnIndex;
                this.ascendingOrder = ascendingOrder;
            }

            public int Compare(object x, object y)
            {
                ListViewItem itemX = x as ListViewItem;
                ListViewItem itemY = y as ListViewItem;

                if (itemX != null && itemY != null)
                {
                    int result = string.Compare(itemX.SubItems[columnIndex].Text, itemY.SubItems[columnIndex].Text);

                    if (!ascendingOrder)
                    {
                        result = -result;
                    }

                    return result;
                }

                return 0;
            }
        }
        private void lv_columnClicked(object sender, ColumnClickEventArgs e)
        {
            if (ascendingOrder)
            {
                ascendingOrder = false;
            }
            else
            {
                ascendingOrder = true;
            }

            reservationData_LV.ListViewItemSorter = new ListViewItemComparer(e.Column, ascendingOrder);
            reservationData_LV.Sort();
        }

        private void Book_a_Room_FormClosing(object sender, FormClosingEventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(fileLoc + "Reservations.txt"))
            {
                foreach (var dic in reservationDict)
                {
                    sw.WriteLine($"{dic.Value[0]};{dic.Value[1]};{dic.Value[2]};{dic.Value[3]};{dic.Value[4]};{dic.Value[5]};{dic.Value[6]};{dic.Value[7]};{dic.Value[8]};{dic.Value[9]};{dic.Value[10]}");
                }
            }
        }

        private void Book_a_Room_Load(object sender, EventArgs e)
        {

        }
    }
}
