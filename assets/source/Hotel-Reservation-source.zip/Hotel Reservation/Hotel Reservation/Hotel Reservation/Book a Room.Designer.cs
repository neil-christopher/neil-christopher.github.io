﻿namespace Hotel_Reservation
{
    partial class Book_a_Room
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.First_TB = new System.Windows.Forms.TextBox();
            this.addBooking = new System.Windows.Forms.Button();
            this.RoomType_CB1 = new System.Windows.Forms.ComboBox();
            this.children_TB = new System.Windows.Forms.TextBox();
            this.Adult_TB = new System.Windows.Forms.TextBox();
            this.SR_TB = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Email_TB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Phone_TB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkOut_DTP = new System.Windows.Forms.DateTimePicker();
            this.checkIn_DTP = new System.Windows.Forms.DateTimePicker();
            this.Last_TB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cancel_button = new System.Windows.Forms.Button();
            this.reservationData_LV = new System.Windows.Forms.ListView();
            this.removeBooking = new System.Windows.Forms.Button();
            this.updateBooking = new System.Windows.Forms.Button();
            this.newBooking = new System.Windows.Forms.Button();
            this.refNo_TB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.searchRef_TB = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // First_TB
            // 
            this.First_TB.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.First_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.First_TB.Location = new System.Drawing.Point(40, 158);
            this.First_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.First_TB.Name = "First_TB";
            this.First_TB.Size = new System.Drawing.Size(183, 25);
            this.First_TB.TabIndex = 28;
            this.First_TB.Text = "First";
            this.First_TB.Enter += new System.EventHandler(this.fname_Enter);
            this.First_TB.Leave += new System.EventHandler(this.fname_Leave);
            // 
            // addBooking
            // 
            this.addBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.addBooking.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.addBooking.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBooking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.addBooking.Location = new System.Drawing.Point(208, 754);
            this.addBooking.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addBooking.Name = "addBooking";
            this.addBooking.Size = new System.Drawing.Size(152, 47);
            this.addBooking.TabIndex = 48;
            this.addBooking.Text = "Add Booking";
            this.addBooking.UseVisualStyleBackColor = false;
            this.addBooking.Click += new System.EventHandler(this.Add_Click);
            // 
            // RoomType_CB1
            // 
            this.RoomType_CB1.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomType_CB1.FormattingEnabled = true;
            this.RoomType_CB1.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Deluxe",
            "Family",
            "Suite"});
            this.RoomType_CB1.Location = new System.Drawing.Point(223, 356);
            this.RoomType_CB1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RoomType_CB1.Name = "RoomType_CB1";
            this.RoomType_CB1.Size = new System.Drawing.Size(183, 25);
            this.RoomType_CB1.TabIndex = 37;
            this.RoomType_CB1.Text = "Select Room Type";
            // 
            // children_TB
            // 
            this.children_TB.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.children_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.children_TB.Location = new System.Drawing.Point(223, 450);
            this.children_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.children_TB.Name = "children_TB";
            this.children_TB.Size = new System.Drawing.Size(183, 25);
            this.children_TB.TabIndex = 45;
            this.children_TB.Text = "# of Children";
            this.children_TB.Enter += new System.EventHandler(this.cnum_Enter);
            this.children_TB.Leave += new System.EventHandler(this.cnum_Leave);
            // 
            // Adult_TB
            // 
            this.Adult_TB.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adult_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Adult_TB.Location = new System.Drawing.Point(223, 404);
            this.Adult_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Adult_TB.Name = "Adult_TB";
            this.Adult_TB.Size = new System.Drawing.Size(183, 25);
            this.Adult_TB.TabIndex = 42;
            this.Adult_TB.Text = "# of Adults";
            this.Adult_TB.Enter += new System.EventHandler(this.anum_Enter);
            this.Adult_TB.Leave += new System.EventHandler(this.anum_Leave);
            // 
            // SR_TB
            // 
            this.SR_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.SR_TB.Location = new System.Drawing.Point(223, 498);
            this.SR_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SR_TB.Multiline = true;
            this.SR_TB.Name = "SR_TB";
            this.SR_TB.Size = new System.Drawing.Size(317, 110);
            this.SR_TB.TabIndex = 46;
            this.SR_TB.Text = "None";
            this.SR_TB.Enter += new System.EventHandler(this.sr_Enter);
            this.SR_TB.Leave += new System.EventHandler(this.sr_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 498);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(130, 23);
            this.label10.TabIndex = 47;
            this.label10.Text = "Special Request";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(36, 452);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 23);
            this.label9.TabIndex = 44;
            this.label9.Text = "Number of Children";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(36, 405);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(147, 23);
            this.label8.TabIndex = 43;
            this.label8.Text = "Number of Adults";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 23);
            this.label7.TabIndex = 41;
            this.label7.Text = "Room Type";
            // 
            // Email_TB
            // 
            this.Email_TB.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Email_TB.Location = new System.Drawing.Point(237, 226);
            this.Email_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Email_TB.Name = "Email_TB";
            this.Email_TB.Size = new System.Drawing.Size(183, 25);
            this.Email_TB.TabIndex = 31;
            this.Email_TB.Text = "E-mail address";
            this.Email_TB.Enter += new System.EventHandler(this.email_Enter);
            this.Email_TB.Leave += new System.EventHandler(this.email_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(233, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 23);
            this.label5.TabIndex = 39;
            this.label5.Text = "Email";
            // 
            // Phone_TB
            // 
            this.Phone_TB.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Phone_TB.Location = new System.Drawing.Point(40, 226);
            this.Phone_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Phone_TB.Name = "Phone_TB";
            this.Phone_TB.Size = new System.Drawing.Size(183, 25);
            this.Phone_TB.TabIndex = 30;
            this.Phone_TB.Text = "+63";
            this.Phone_TB.Enter += new System.EventHandler(this.pnum_Enter);
            this.Phone_TB.Leave += new System.EventHandler(this.pnum_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 23);
            this.label4.TabIndex = 38;
            this.label4.Text = "Phone";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(297, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 23);
            this.label3.TabIndex = 35;
            this.label3.Text = "Check Out";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 23);
            this.label2.TabIndex = 33;
            this.label2.Text = "Check In";
            // 
            // checkOut_DTP
            // 
            this.checkOut_DTP.CustomFormat = "MM/dd/yyyy";
            this.checkOut_DTP.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOut_DTP.Location = new System.Drawing.Point(301, 298);
            this.checkOut_DTP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkOut_DTP.Name = "checkOut_DTP";
            this.checkOut_DTP.Size = new System.Drawing.Size(239, 25);
            this.checkOut_DTP.TabIndex = 34;
            this.checkOut_DTP.Value = new System.DateTime(2024, 11, 15, 0, 0, 0, 0);
            // 
            // checkIn_DTP
            // 
            this.checkIn_DTP.CustomFormat = "MM/dd/yyyy";
            this.checkIn_DTP.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkIn_DTP.Location = new System.Drawing.Point(40, 298);
            this.checkIn_DTP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkIn_DTP.Name = "checkIn_DTP";
            this.checkIn_DTP.Size = new System.Drawing.Size(239, 25);
            this.checkIn_DTP.TabIndex = 32;
            this.checkIn_DTP.Value = new System.DateTime(2024, 11, 15, 0, 0, 0, 0);
            // 
            // Last_TB
            // 
            this.Last_TB.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Last_TB.ForeColor = System.Drawing.SystemColors.GrayText;
            this.Last_TB.Location = new System.Drawing.Point(237, 158);
            this.Last_TB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Last_TB.Name = "Last_TB";
            this.Last_TB.Size = new System.Drawing.Size(183, 25);
            this.Last_TB.TabIndex = 29;
            this.Last_TB.Text = "Last";
            this.Last_TB.Enter += new System.EventHandler(this.lname_Enter);
            this.Last_TB.Leave += new System.EventHandler(this.lname_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 23);
            this.label1.TabIndex = 27;
            this.label1.Text = "First / Last Name";
            // 
            // cancel_button
            // 
            this.cancel_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.cancel_button.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cancel_button.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel_button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.cancel_button.Location = new System.Drawing.Point(37, 26);
            this.cancel_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(152, 47);
            this.cancel_button.TabIndex = 53;
            this.cancel_button.Text = "Return";
            this.cancel_button.UseVisualStyleBackColor = false;
            this.cancel_button.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // reservationData_LV
            // 
            this.reservationData_LV.FullRowSelect = true;
            this.reservationData_LV.HideSelection = false;
            this.reservationData_LV.Location = new System.Drawing.Point(673, 126);
            this.reservationData_LV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.reservationData_LV.MultiSelect = false;
            this.reservationData_LV.Name = "reservationData_LV";
            this.reservationData_LV.Size = new System.Drawing.Size(1292, 570);
            this.reservationData_LV.TabIndex = 54;
            this.reservationData_LV.UseCompatibleStateImageBehavior = false;
            this.reservationData_LV.View = System.Windows.Forms.View.Details;
            this.reservationData_LV.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lv_columnClicked);
            this.reservationData_LV.SelectedIndexChanged += new System.EventHandler(this.reservationData_LV_SelectedIndexChanged);
            // 
            // removeBooking
            // 
            this.removeBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.removeBooking.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.removeBooking.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeBooking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.removeBooking.Location = new System.Drawing.Point(576, 754);
            this.removeBooking.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.removeBooking.Name = "removeBooking";
            this.removeBooking.Size = new System.Drawing.Size(152, 47);
            this.removeBooking.TabIndex = 55;
            this.removeBooking.Text = "Remove";
            this.removeBooking.UseVisualStyleBackColor = false;
            this.removeBooking.Click += new System.EventHandler(this.removeBooking_Click);
            // 
            // updateBooking
            // 
            this.updateBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.updateBooking.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.updateBooking.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBooking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.updateBooking.Location = new System.Drawing.Point(392, 754);
            this.updateBooking.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updateBooking.Name = "updateBooking";
            this.updateBooking.Size = new System.Drawing.Size(152, 47);
            this.updateBooking.TabIndex = 56;
            this.updateBooking.Text = "Update";
            this.updateBooking.UseVisualStyleBackColor = false;
            this.updateBooking.Click += new System.EventHandler(this.updateBooking_Click);
            // 
            // newBooking
            // 
            this.newBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.newBooking.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.newBooking.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBooking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.newBooking.Location = new System.Drawing.Point(24, 754);
            this.newBooking.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.newBooking.Name = "newBooking";
            this.newBooking.Size = new System.Drawing.Size(152, 47);
            this.newBooking.TabIndex = 57;
            this.newBooking.Text = "New Booking";
            this.newBooking.UseVisualStyleBackColor = false;
            this.newBooking.Click += new System.EventHandler(this.newBooking_Click);
            // 
            // refNo_TB
            // 
            this.refNo_TB.Enabled = false;
            this.refNo_TB.Location = new System.Drawing.Point(223, 647);
            this.refNo_TB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.refNo_TB.Name = "refNo_TB";
            this.refNo_TB.Size = new System.Drawing.Size(317, 22);
            this.refNo_TB.TabIndex = 58;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 647);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 23);
            this.label6.TabIndex = 59;
            this.label6.Text = "Reference No.";
            // 
            // searchRef_TB
            // 
            this.searchRef_TB.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.searchRef_TB.Location = new System.Drawing.Point(755, 75);
            this.searchRef_TB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.searchRef_TB.Name = "searchRef_TB";
            this.searchRef_TB.Size = new System.Drawing.Size(367, 22);
            this.searchRef_TB.TabIndex = 60;
            this.searchRef_TB.Text = "Enter Reference No.";
            this.searchRef_TB.Enter += new System.EventHandler(this.ro_Enter);
            this.searchRef_TB.Leave += new System.EventHandler(this.ro_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(668, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 23);
            this.label11.TabIndex = 61;
            this.label11.Text = "Search";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1131, 75);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(67, 23);
            this.button1.TabIndex = 62;
            this.button1.Text = "search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Book_a_Room
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1060);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.searchRef_TB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.refNo_TB);
            this.Controls.Add(this.newBooking);
            this.Controls.Add(this.updateBooking);
            this.Controls.Add(this.removeBooking);
            this.Controls.Add(this.reservationData_LV);
            this.Controls.Add(this.cancel_button);
            this.Controls.Add(this.First_TB);
            this.Controls.Add(this.addBooking);
            this.Controls.Add(this.RoomType_CB1);
            this.Controls.Add(this.children_TB);
            this.Controls.Add(this.Adult_TB);
            this.Controls.Add(this.SR_TB);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Email_TB);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Phone_TB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkOut_DTP);
            this.Controls.Add(this.checkIn_DTP);
            this.Controls.Add(this.Last_TB);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Book_a_Room";
            this.Text = "Book_a_Room";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Book_a_Room_FormClosing);
            this.Load += new System.EventHandler(this.Book_a_Room_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox First_TB;
        private System.Windows.Forms.Button addBooking;
        private System.Windows.Forms.ComboBox RoomType_CB1;
        private System.Windows.Forms.TextBox children_TB;
        private System.Windows.Forms.TextBox Adult_TB;
        private System.Windows.Forms.TextBox SR_TB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Email_TB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Phone_TB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker checkOut_DTP;
        private System.Windows.Forms.DateTimePicker checkIn_DTP;
        private System.Windows.Forms.TextBox Last_TB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.ListView reservationData_LV;
        private System.Windows.Forms.Button removeBooking;
        private System.Windows.Forms.Button updateBooking;
        private System.Windows.Forms.Button newBooking;
        private System.Windows.Forms.TextBox refNo_TB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox searchRef_TB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
    }
}