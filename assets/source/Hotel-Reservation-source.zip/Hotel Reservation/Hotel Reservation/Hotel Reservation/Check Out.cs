﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hotel_Reservation
{
    public partial class Check_Out : Form
    {
        public Check_Out()
        {
            InitializeComponent();
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            string referenceNumber = txtReferenceNumber.Text;
            string customerName = txtCustomerName.Text;
            string paymentAmount = txtPaymentAmount.Text;
            string checkoutDate = dateTimePickerCheckout.Value.ToString("yyyy-MM-dd");

            if (string.IsNullOrWhiteSpace(referenceNumber) ||
                string.IsNullOrWhiteSpace(customerName) ||
                string.IsNullOrWhiteSpace(paymentAmount))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string fileName = $"Checkout_{referenceNumber}.txt";
            string content = $"Reference Number: {referenceNumber}\n" +
                             $"Customer Name: {customerName}\n" +
                             $"Payment Amount: {paymentAmount}\n" +
                             $"Checkout Date: {checkoutDate}";

            try
            {
                File.WriteAllText(fileName, content);
                MessageBox.Show($"Checkout details saved to file:\n{fileName}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
                //Change to Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving to file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtReferenceNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePickerCheckout_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtPaymentAmount_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
