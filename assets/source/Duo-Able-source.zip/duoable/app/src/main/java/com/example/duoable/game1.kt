package com.example.duoable

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle

@Composable
fun SliderGameScreen(isPlayer2: Boolean, onButtonClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (!isPlayer2) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 40.dp),
                verticalArrangement = Arrangement.spacedBy(60.dp)
            ) {
                HorizontalSlider(modifier = Modifier.fillMaxWidth())
                HorizontalSlider(modifier = Modifier.fillMaxWidth())
                HorizontalSlider(modifier = Modifier.fillMaxWidth())
            }

            Image(
                painter = painterResource(id = R.drawable.key),
                contentDescription = "Key Image",
                modifier = Modifier
                    .size(width = 150.dp, height = 150.dp)
                    .align(Alignment.BottomCenter)
                    .offset(x = (-5).dp, y = (-20).dp)
                    .clickable { onButtonClick() }
            )
        } else {
            Text(
                text = "Dear Marga,\n\nI have seen 3 dalmatians yesterday and Marites saw me but she didn't talk to me. An hour later I spoke to Mr. Shoeman to gossip about Marites well, he didn't say anything because he was too busy shining 3 clients' shoes.",
                color = Color.White,
                fontSize = 18.sp,
                textAlign = TextAlign.Left,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-70).dp)
                    .padding(start = 40.dp, end = 40.dp, top = 100.dp)
            )
        }

        Image(
            painter = painterResource(id = R.drawable.redbutton),
            contentDescription = "Red Button",
            modifier = Modifier
                .size(50.dp)
                .align(Alignment.BottomEnd)
                .offset(x = (-40).dp, y = (-180).dp)
        )
    }
}

@Composable
fun HorizontalSlider(modifier: Modifier = Modifier) {
    val numLines = 7
    val circleRadius = 15.dp
    val lineHeight = 30.dp
    val lineWidth = 2.dp
    val sliderHeight = 4.dp

    var circleOffsetX by remember { mutableStateOf(0f) }
    var sliderWidthPx by remember { mutableStateOf(0f) }

    val density = LocalDensity.current

    Box(
        modifier = modifier
            .height(lineHeight * 2)
            .onGloballyPositioned { coordinates ->
                sliderWidthPx = coordinates.size.width.toFloat()
                if (circleOffsetX == 0f) {
                    circleOffsetX = sliderWidthPx - with(density) { (circleRadius * 2).toPx() }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerY = canvasHeight / 2f

            drawLine(
                color = Color.White,
                start = Offset(0f, centerY),
                end = Offset(canvasWidth, centerY),
                strokeWidth = with(density) { sliderHeight.toPx() }
            )

            val segmentWidth = canvasWidth / (numLines - 1)

            for (i in 0 until numLines) {
                val x = i * segmentWidth
                drawLine(
                    color = Color.White,
                    start = Offset(x, centerY - with(density) { lineHeight.toPx() } / 2),
                    end = Offset(x, centerY + with(density) { lineHeight.toPx() } / 2),
                    strokeWidth = with(density) { lineWidth.toPx() }
                )
            }
        }

        Box(
            modifier = Modifier
                .offset(x = with(density) { circleOffsetX.toDp() })
                .size(circleRadius * 2)
                .background(Color.White, CircleShape)
                .align(Alignment.CenterStart)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val newOffsetX = circleOffsetX + dragAmount.x
                        val minOffsetX = 0f
                        val maxOffsetX = sliderWidthPx - with(density) { (circleRadius * 2).toPx() }
                        circleOffsetX = newOffsetX.coerceIn(minOffsetX, maxOffsetX)
                    }
                }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewSliderGameScreenP1() {
    SliderGameScreen(isPlayer2 = false, onButtonClick = {})
}

@Preview(showBackground = true)
@Composable
fun PreviewSliderGameScreenP2() {
    SliderGameScreen(isPlayer2 = true, onButtonClick = {})
}

@Preview(showBackground = true)
@Composable
fun PreviewHorizontalSlider() {
    HorizontalSlider(modifier = Modifier.width(300.dp))
}
