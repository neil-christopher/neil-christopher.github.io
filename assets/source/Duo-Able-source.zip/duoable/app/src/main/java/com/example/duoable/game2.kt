package com.example.duoable

import android.widget.Button
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.Size

@Composable
fun RadioGameScreen(onRedButtonClick: () -> Unit) {

    val sliderIndex = remember { mutableStateOf(0) }

    val letterMap = remember {
        mapOf(
            5 to Triple("A", Offset(-80f, -120f), 30.sp),
            6 to Triple("F", Offset(50f, -120f), 28.sp),
            1 to Triple("D", Offset(100f, -140f), 32.sp),
            3 to Triple("G", Offset(-30f, -140f), 26.sp)
        )
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Text(
            text = "Margarett and I still would love to\n" +
                    "roam around the park, have a\n" +
                    "picnic, and enjoy the summer\n" +
                    "shimmering. The thing is, I couldn't\n" +
                    "find a way to give her a ring. There\n" +
                    "has to do something.",
            color = Color.White,
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .align(Alignment.TopCenter)
                .offset(y = 70.dp)
        )

        Image(
            painter = painterResource(id = R.drawable.radio),
            contentDescription = "Radio",
            modifier = Modifier
                .size(150.dp, 200.dp)
                .align(Alignment.Center)
                .offset(y = (-10).dp)
        )
        letterMap[sliderIndex.value]?.let{(char,offset,fontSize) ->
            Text(
                text = char,
                color = Color.White,
                fontSize = fontSize,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(x = offset.x.dp, y = offset.y.dp)
            )
        }

//        val letterData = remember {
//            listOf(
//                Triple("A", Offset(-80f, -120f), 30.sp),
//                Triple("F", Offset(50f, -120f), 28.sp),
//                Triple("D", Offset(100f, -140f), 32.sp),
//                Triple("G", Offset(-30f, -140f), 26.sp)
//            )
//        }
//
//        letterData.forEach { (char, offset, fontSize) ->
//            Text(
//                text = char,
//                color = Color.White,
//                fontSize = fontSize,
//                modifier = Modifier
//                    .align(Alignment.Center)
//                    .offset(x = offset.x.dp, y = offset.y.dp)
//            )
//        }

        HorizontalSliderRadio(
            currentIndex = sliderIndex,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .align(Alignment.Center)
                .offset(y = 140.dp)

        )


        Image(
            painter = painterResource(id = R.drawable.redbutton),
            contentDescription = "Red Button",
            modifier = Modifier
                .size(50.dp)
                .align(Alignment.BottomEnd)
                .offset(x = (-40).dp, y = (-150).dp)
                .clickable {onRedButtonClick() }
        )
    }
}

@Composable
fun HorizontalSliderRadio(modifier: Modifier = Modifier, currentIndex: MutableState<Int>) {
    val numLines = 8
    val circleRadius = 15.dp
    val lineHeight = 30.dp
    val lineWidth = 2.dp
    val sliderHeight = 4.dp

    var circleOffsetX by remember { mutableStateOf(0f) }
    var sliderWidthPx by remember { mutableStateOf(0f) }

    val density = LocalDensity.current

    Box(
        modifier = modifier
            .height(lineHeight * 2)
            .onGloballyPositioned { coordinates ->
                sliderWidthPx = coordinates.size.width.toFloat()
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerY = canvasHeight / 2f

            drawLine(
                color = Color.White,
                start = Offset(0f, centerY),
                end = Offset(canvasWidth, centerY),
                strokeWidth = with(density) { sliderHeight.toPx() }
            )

            val segmentWidth = canvasWidth / (numLines - 1)

            for (i in 0 until numLines) {
                val x = i * segmentWidth
                drawLine(
                    color = Color.White,
                    start = Offset(x, centerY - with(density) { lineHeight.toPx() } / 2),
                    end = Offset(x, centerY + with(density) { lineHeight.toPx() } / 2),
                    strokeWidth = with(density) { lineWidth.toPx() }
                )
            }
        }

        Box(
            modifier = Modifier
                .offset(x = with(density) { circleOffsetX.toDp() })
                .size(circleRadius * 2)
                .background(Color.White, CircleShape)
                .align(Alignment.CenterStart)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val newOffsetX = (circleOffsetX + dragAmount.x)
                            .coerceIn(0f, sliderWidthPx - with(density) { (circleRadius * 2).toPx() })
                        circleOffsetX = newOffsetX


                        val segmentWidth = sliderWidthPx / (numLines - 1)
                        val index = ((circleOffsetX + segmentWidth / 2) / segmentWidth).toInt()
                        currentIndex.value = index.coerceIn(0, numLines - 1)
                    }
                }
        )
    }
}

@Composable
fun PianoGameScreen(onRedButtonClick: () -> Unit) {
    val showkey = remember { mutableStateOf(false) }
    val correctSequence = listOf("D", "G", "A", "F")

    val clickedNotes = remember { mutableStateListOf<String>() }
    val maxNotesToDisplay = 4

    fun onKeyClick(note: String) {
        if (clickedNotes.size < maxNotesToDisplay) {
            clickedNotes.add(note)
        } else {
            clickedNotes.removeAt(0)
            clickedNotes.add(note)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(top = 100.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            val boxModifier = Modifier
                .size(45.dp)
                .background(Color.LightGray)
                .padding(4.dp)

            for (i in 0 until maxNotesToDisplay) {
                val noteToDisplay = clickedNotes.getOrNull(i) ?: ""
                Box(modifier = boxModifier, contentAlignment = Alignment.Center) {
                    Text(
                        text = noteToDisplay,
                        fontSize = 18.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (i < maxNotesToDisplay - 1) {
                    Spacer(Modifier.width(8.dp))
                }
            }
        }
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 150.dp)
                .width(IntrinsicSize.Min)
        ) {
            val whiteKeyWidth = 40.dp
            val whiteKeyHeight = 150.dp
            val blackKeyWidth = 25.dp
            val blackKeyHeight = 80.dp

            @Composable
            fun WhiteKey(letter: String, modifier: Modifier = Modifier) {

                Box(
                    modifier = modifier
                        .size(whiteKeyWidth, whiteKeyHeight)
                        .border(1.dp, Color.Black)
                        .background(Color.White)
                        .clickable { onKeyClick(letter) },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Text(
                        text = letter,
                        color = Color.Black,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
            }


            Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                WhiteKey("A")
                WhiteKey("B")
                WhiteKey("C")
                WhiteKey("D")
                WhiteKey("E")
                WhiteKey("F")
                WhiteKey("G")
            }

            Box(
                modifier = Modifier
                    .offset(x = whiteKeyWidth - blackKeyWidth / 2)
                    .size(blackKeyWidth, blackKeyHeight)
                    .background(Color.Black)
                    .align(Alignment.TopStart)
                    .clickable { onKeyClick("A#") }
            )

            Box(
                modifier = Modifier
                    .offset(x = (whiteKeyWidth * 2) + whiteKeyWidth - blackKeyWidth / 2)
                    .size(blackKeyWidth, blackKeyHeight)
                    .background(Color.Black)
                    .align(Alignment.TopStart)
                    .clickable { onKeyClick("C#") }
            )

            Box(
                modifier = Modifier
                    .offset(x = (whiteKeyWidth * 5) + whiteKeyWidth - blackKeyWidth / 2)
                    .size(blackKeyWidth, blackKeyHeight)
                    .background(Color.Black)
                    .align(Alignment.TopStart)
                    .clickable { onKeyClick("F#") }
            )
        }

        Image(
            painter = painterResource(id = R.drawable.redbutton),
            contentDescription = "Red Button",
            modifier = Modifier
                .size(50.dp)
                .align(Alignment.BottomEnd)
                .offset(x = (-40).dp, y = (-150).dp)
                .clickable {
                    if (clickedNotes.map { it.uppercase() } == correctSequence)
                    {
                        showkey.value = true


                    } else {
                        clickedNotes.clear()
                    }
                }
        )
        if (showkey.value) {
            Image(
                painter = painterResource(id = R.drawable.key),
                contentDescription = "Golden Key",
                modifier = Modifier
                    .size(width = 150.dp, height = 150.dp)
                    .align(Alignment.BottomCenter)
                    .offset(x = (-5).dp, y = (-20).dp)
                    .clickable { onRedButtonClick() }

            )
            Text(
                text = "Nice! You got it correct.",
                color = Color.Black,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .align(Alignment.Center)
                    .offset(y = 70.dp)
            )

        }
        else{
            Text(
                text = "Guess the notes.",
                color = Color.Black,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .align(Alignment.Center)
                    .offset(y = 70.dp)

            )
        }
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 640)
@Composable
fun PreviewPianoGameScreen() {
    PianoGameScreen(onRedButtonClick = {})
}

@Preview(showBackground = true)
@Composable
fun PreviewRadioGameScreen() {
    RadioGameScreen(onRedButtonClick = {})
}

//@Preview(showBackground = true)
//@Composable
//fun PreviewHorizontalSliderRadio() {
//    HorizontalSliderRadio(modifier = Modifier.width(300.dp))
//}
