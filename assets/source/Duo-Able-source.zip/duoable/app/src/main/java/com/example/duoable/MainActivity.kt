package com.example.duoable

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                AppNavigation()
            }
        }
    }

    @Composable
    fun AppNavigation() {
        var currentScreen by remember { mutableStateOf<Screen>(Screen.MainMenu) }
        var gameStartTime by remember { mutableStateOf(0L) }
        var gameTime by remember { mutableStateOf("00:00:00") }

        when (currentScreen) {
            is Screen.MainMenu -> MainMenu(
                onPlayer1Click = { currentScreen = Screen.Player1Screen },
                onPlayer2Click = { currentScreen = Screen.Player2Screen }
            )

            is Screen.Player1Screen -> Player1Screen(
                onBackClick = { currentScreen = Screen.MainMenu },
                onNextClick = { currentScreen = Screen.Player1InfoScreen }
            )

            is Screen.Player1InfoScreen -> Player1InfoScreen(
                onBackClick = { currentScreen = Screen.Player1Screen },
                onNextClick = { currentScreen = Screen.Player1CommunicationScreen }
            )

            is Screen.Player1CommunicationScreen -> Player1CommunicationScreen(
                onBackClick = { currentScreen = Screen.Player1InfoScreen },
                onNextClick = { currentScreen = Screen.Player2TrustScreen }
            )

            is Screen.Player2TrustScreen -> Player2TrustScreen(
                onBackClick = { currentScreen = Screen.Player1CommunicationScreen },
                onNextClick = { currentScreen = Screen.GameStartScreen(isPlayer2 = false) }
            )

            is Screen.Player2Screen -> Player2Screen(
                onBackClick = { currentScreen = Screen.MainMenu },
                onNextClick = { currentScreen = Screen.Player2InfoScreen }
            )

            is Screen.Player2InfoScreen -> Player2InfoScreen(
                onBackClick = { currentScreen = Screen.Player2Screen },
                onNextClick = { currentScreen = Screen.Player2CommunicationScreen }
            )

            is Screen.Player2CommunicationScreen -> Player2CommunicationScreen(
                onBackClick = { currentScreen = Screen.Player2InfoScreen },
                onNextClick = { currentScreen = Screen.Player1TrustScreen }
            )

            is Screen.Player1TrustScreen -> Player1TrustScreen(
                onBackClick = { currentScreen = Screen.Player2CommunicationScreen },
                onNextClick = { currentScreen = Screen.GameStartScreen(isPlayer2 = true) }
            )

            is Screen.GameStartScreen -> {
                val playerIsPlayer2 = (currentScreen as Screen.GameStartScreen).isPlayer2
                GameStartScreen(
                    onBackClick = {
                        currentScreen = if (playerIsPlayer2) {
                            Screen.Player1TrustScreen
                        } else {
                            Screen.Player2TrustScreen
                        }
                    },
                    onStartClick = {
                        gameStartTime = System.currentTimeMillis()
                        currentScreen = Screen.SliderGame(playerIsPlayer2)
                    }
                )
            }

            is Screen.SliderGame -> SliderGameScreen(
                isPlayer2 = (currentScreen as Screen.SliderGame).isPlayer2,
                onButtonClick = {
                    if ((currentScreen as Screen.SliderGame).isPlayer2) {
                        currentScreen = Screen.Player2ConfirmKey
                    } else {
                        currentScreen = Screen.RadioGame
                    }
                }
            )

            is Screen.Player2ConfirmKey -> Player2ConfirmationScreen(
                onBackClick = { currentScreen = Screen.SliderGame(isPlayer2 = true) },
                onNextClick = {
                    currentScreen = Screen.PianoGame
                }
            )

            is Screen.RadioGame -> RadioGameScreen(
                onRedButtonClick = {
                    currentScreen = Screen.Player1RadioConfirmation
                }
            )

            is Screen.Player1RadioConfirmation -> Player1RadioConfirmationScreen(
                onBackClick = { currentScreen = Screen.RadioGame },
                onNextClick = {
                    currentScreen = Screen.Round3(isPlayer2 = false)
                }
            )

            is Screen.PianoGame -> PianoGameScreen(
                onRedButtonClick = {
                    currentScreen = Screen.Round3(isPlayer2 = true)
                }
            )
            is Screen.Round3 -> {
                val isPlayer2 = (currentScreen as Screen.Round3).isPlayer2
                if (isPlayer2) {
                    Round3Player2(
                        onButtonClick = {
                            val endTime = System.currentTimeMillis()
                            val durationMillis = endTime - gameStartTime
                            val seconds = (durationMillis / 1000) % 60
                            val minutes = (durationMillis / (1000 * 60)) % 60
                            val hours = (durationMillis / (1000 * 60 * 60))

                            gameTime = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                            currentScreen = Screen.VictoryScreen
                        }
                    )
                } else {
                    Round3Player1(
                        onButtonClick = {
                            val endTime = System.currentTimeMillis()
                            val durationMillis = endTime - gameStartTime
                            val seconds = (durationMillis / 1000) % 60
                            val minutes = (durationMillis / (1000 * 60)) % 60
                            val hours = (durationMillis / (1000 * 60 * 60))

                            gameTime = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                            currentScreen = Screen.VictoryScreen
                        }
                    )
                }
            }
            is Screen.VictoryScreen -> {
                VictoryScreen(
                    gameTime = gameTime,
                    onNext2Click = { currentScreen = Screen.ThanksScreen },
                    onRecordTimeClick = { }

                )
            }
            is Screen.ThanksScreen -> {
                ThanksScreen(
                    onSuggestClick = {

                    },
                    onPlayAgainClick = {
                        currentScreen = Screen.MainMenu
                    }
                )
            }


        }
    }

    sealed class Screen {
        object MainMenu : Screen()
        object Player1Screen : Screen()
        object Player1InfoScreen : Screen()
        object Player1CommunicationScreen : Screen()
        object Player2TrustScreen : Screen()
        object Player2Screen : Screen()
        object Player2InfoScreen : Screen()
        object Player2CommunicationScreen : Screen()
        object Player1TrustScreen : Screen()
        data class GameStartScreen(val isPlayer2: Boolean) : Screen()
        data class SliderGame(val isPlayer2: Boolean) : Screen()
        object Player2ConfirmKey : Screen()
        object RadioGame : Screen()
        object Player1RadioConfirmation : Screen()
        object PianoGame : Screen()
        data class Round3(val isPlayer2: Boolean) :Screen()
        object VictoryScreen : Screen()
        object ThanksScreen : Screen()
    }

    @Composable
    fun MainMenu(onPlayer1Click: () -> Unit, onPlayer2Click: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Duo-Able Logo",
                modifier = Modifier
                    .size(width = 470.dp, height = 250.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 50.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.player1),
                contentDescription = "Player 1 Button",
                modifier = Modifier
                    .size(500.dp, 300.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 220.dp)
                    .clickable { onPlayer1Click() }
            )

            Image(
                painter = painterResource(id = R.drawable.player2),
                contentDescription = "Player 2 Button",
                modifier = Modifier
                    .size(500.dp, 310.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 320.dp)
                    .clickable { onPlayer2Click() }
            )

            Image(
                painter = painterResource(id = R.drawable.achievement),
                contentDescription = "Achievement Button",
                modifier = Modifier
                    .size(400.dp, 270.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 440.dp)
                    .clickable { }
            )

            Image(
                painter = painterResource(id = R.drawable.quitbttn),
                contentDescription = "Quit Button",
                modifier = Modifier
                    .size(500.dp, 310.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 520.dp)
                    .clickable { }
            )
        }
    }

    @Composable
    fun Player1Screen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.p1),
                contentDescription = "Player 1 Header",
                modifier = Modifier
                    .size(width = 400.dp, height = 180.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 230.dp),
                contentScale = ContentScale.Fit
            )

            Text(
                text = "Make sure your partner is in Player 2",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 400.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.back),
                contentDescription = "Back Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .clickable { onBackClick() },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(id = R.drawable.next),
                contentDescription = "Next Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .clickable { onNextClick() },
                contentScale = ContentScale.Fit
            )
        }
    }

    @Composable
    fun Player1InfoScreen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.p1),
                contentDescription = "Player 1 Header",
                modifier = Modifier
                    .size(width = 400.dp, height = 180.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 230.dp),
                contentScale = ContentScale.Fit
            )

            Text(
                text = "You can each play duo-able on your preferred platform. No connection is required between devices",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 400.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.back),
                contentDescription = "Back Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .clickable { onBackClick() },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(id = R.drawable.next),
                contentDescription = "Next Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .clickable { onNextClick() },
                contentScale = ContentScale.Fit
            )
        }
    }

    @Composable
    fun Player1CommunicationScreen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.p1),
                contentDescription = "Player 1 Header",
                modifier = Modifier
                    .size(width = 400.dp, height = 180.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 230.dp),
                contentScale = ContentScale.Fit
            )

            Text(
                text = "You both need to communicate. If you are in the same room, try not to look at each others screen. If stuck, feel free to take a peek for hint.",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 400.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.back),
                contentDescription = "Back Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .clickable { onBackClick() },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(id = R.drawable.next),
                contentDescription = "Next Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .clickable { onNextClick() },
                contentScale = ContentScale.Fit
            )
        }
    }

    @Composable
    fun Player2TrustScreen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Text(
                text = "Do you trust the person in Player 2?",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 350.dp)
            )

            Box(
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                    .clickable { onBackClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Back",
                    color = Color.White,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
            }

            Box(
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                    .clickable { onNextClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Next",
                    color = Color.White,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    @Composable
    fun Player2Screen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.p2),
                contentDescription = "Player 2 Header",
                modifier = Modifier
                    .size(width = 400.dp, height = 180.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 230.dp),
                contentScale = ContentScale.Fit
            )

            Text(
                text = "Make sure your partner is in Player 1",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 400.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.back),
                contentDescription = "Back Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .clickable { onBackClick() },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(id = R.drawable.next),
                contentDescription = "Next Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .clickable { onNextClick() },
                contentScale = ContentScale.Fit
            )
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////

    @Composable
    fun Player2InfoScreen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.p2),
                contentDescription = "Player 2 Header",
                modifier = Modifier
                    .size(width = 400.dp, height = 180.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 230.dp),
                contentScale = ContentScale.Fit
            )

            Text(
                text = "You can each play duo-able on your preferred platform. No connection is required between devices",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 400.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.back),
                contentDescription = "Back Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .clickable { onBackClick() },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(id = R.drawable.next),
                contentDescription = "Next Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .clickable { onNextClick() },
                contentScale = ContentScale.Fit
            )
        }
    }

    @Composable
    fun Player2CommunicationScreen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                painter = painterResource(id = R.drawable.p2),
                contentDescription = "Player 2 Header",
                modifier = Modifier
                    .size(width = 400.dp, height = 180.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 230.dp),
                contentScale = ContentScale.Fit
            )

            Text(
                text = "You both need to communicate. If you are in the same room, try not to look at each others screen. If stuck, feel free to take a peek for hint.",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 400.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.back),
                contentDescription = "Back Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .clickable { onBackClick() },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(id = R.drawable.next),
                contentDescription = "Next Button",
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .clickable { onNextClick() },
                contentScale = ContentScale.Fit
            )
        }
    }

    @Composable
    fun Player1TrustScreen(onBackClick: () -> Unit, onNextClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Text(
                text = "Do you trust the person in Player 1?",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 350.dp)
            )

            Box(
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                    .clickable { onBackClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Back",
                    color = Color.White,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
            }

            Box(
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                    .clickable { onNextClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Next",
                    color = Color.White,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    @Composable
    fun GameStartScreen(onBackClick: () -> Unit, onStartClick: () -> Unit) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Text(
                text = "Both of you must click the same button EXACTLY the same time to start",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .align(Alignment.TopCenter)
                    .offset(y = 350.dp)
            )

            Box(
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = 30.dp, y = (-80).dp)
                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                    .clickable { onBackClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Back",
                    color = Color.White,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
            }

            Box(
                modifier = Modifier
                    .size(width = 150.dp, height = 80.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-80).dp)
                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                    .clickable { onStartClick() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Start",
                    color = Color.White,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

///////////////////////////////////////////////////////

    @Composable
    fun SliderGameScreen(isPlayer2: Boolean, onButtonClick: () -> Unit) {
        val slider1Index = remember { mutableStateOf(0) }
        val slider2Index = remember { mutableStateOf(0) }
        val slider3Index = remember { mutableStateOf(0) }
        var showkey by remember {mutableStateOf(false)}

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (!isPlayer2) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(60.dp)
                ) {
                    HorizontalSlider(modifier = Modifier.fillMaxWidth(), currentIndex = slider1Index)
                    HorizontalSlider(modifier = Modifier.fillMaxWidth(), currentIndex = slider2Index)
                    HorizontalSlider(modifier = Modifier.fillMaxWidth(), currentIndex = slider3Index)
                }
                //Lalabas yung key pag tama
                if (showkey) {
                    Image(
                        painter = painterResource(id = R.drawable.key),
                        contentDescription = "Key Image",
                        modifier = Modifier
                            .size(width = 150.dp, height = 150.dp)
                            .align(Alignment.BottomCenter)
                            .offset(x = (-5).dp, y = (-20).dp)
                            .clickable { onButtonClick() }
                    )
                }
            } else {
                Text(
                    text = "Dear Marga,\n\nI have seen 3 dalmatians yesterday and Marites saw me but she didn't talk to me. An hour later I spoke to Mr. Shoeman to gossip about Marites well, he didn't say anything because he was too busy shining 3 clients' shoes.",
                    color = Color.White,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Left,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = (-70).dp)
                        .padding(start = 40.dp, end = 40.dp, top = 100.dp)
                )
            }

            Image(
                painter = painterResource(id = R.drawable.redbutton),
                contentDescription = "Red Button",
                modifier = Modifier
                    .size(50.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-40).dp, y = (-180).dp)
                    .clickable{
                        if (!isPlayer2){
                            val correctCombo = listOf(2,0,2)
                            val currentCombo = listOf(
                                slider1Index.value,
                                slider2Index.value,
                                slider3Index.value
                            )
                            showkey = currentCombo == correctCombo
                        }
                        else{
                            onButtonClick()
                        }
                    }
            )
        }
    }

    @Composable
    fun HorizontalSlider(modifier: Modifier = Modifier, currentIndex: MutableState<Int>) {
        val numLines = 7
        val circleRadius = 15.dp
        val lineHeight = 30.dp
        val lineWidth = 2.dp
        val sliderHeight = 4.dp


        var circleOffsetX by remember { mutableStateOf(0f) }
        var sliderWidthPx by remember { mutableStateOf(0f) }

        val density = LocalDensity.current

        Box(
            modifier = modifier
                .height(lineHeight * 2)
                .onGloballyPositioned { coordinates ->
                    sliderWidthPx = coordinates.size.width.toFloat()
                    val segmentWidth = sliderWidthPx / (numLines - 1)
                    circleOffsetX = segmentWidth * currentIndex.value
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val centerY = canvasHeight / 2f

                drawLine(
                    color = Color.White,
                    start = Offset(0f, centerY),
                    end = Offset(canvasWidth, centerY),
                    strokeWidth = with(density) { sliderHeight.toPx() }
                )

                val segmentWidth = canvasWidth / (numLines - 1)

                for (i in 0 until numLines) {
                    val x = i * segmentWidth
                    drawLine(
                        color = Color.White,
                        start = Offset(x, centerY - with(density) { lineHeight.toPx() } / 2),
                        end = Offset(x, centerY + with(density) { lineHeight.toPx() } / 2),
                        strokeWidth = with(density) { lineWidth.toPx() }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .offset(x = with(density) { circleOffsetX.toDp() })
                    .size(circleRadius * 2)
                    .background(Color.White, CircleShape)
                    .align(Alignment.CenterStart)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                circleOffsetX = (circleOffsetX + dragAmount.x).coerceIn(0f, sliderWidthPx)
                            },
                            onDragEnd = {
                                //Pupunta sa nearest horizontal line
                                val segmentWidth = sliderWidthPx / (numLines - 1)
                                val newIndex = (circleOffsetX / segmentWidth).roundToInt().coerceIn(0, numLines - 1)
                                currentIndex.value = newIndex
                                circleOffsetX = newIndex * segmentWidth
                            }
                        )
                    }
            )
        }
    }

    @Composable
    fun Player2ConfirmationScreen(
        onBackClick: () -> Unit,
        onNextClick: () -> Unit
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(300.dp)
                    .height(250.dp)
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceAround
            ) {
                Text(
                    text = "Are you sure Player 1 got the golden key?",
                    color = Color.Black,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onBackClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Back", color = Color.Black, fontSize = 18.sp)
                    }

                    Button(
                        onClick = onNextClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Next", color = Color.Black, fontSize = 18.sp)
                    }
                }
            }

            Image(
                painter = painterResource(id = R.drawable.redbutton),
                contentDescription = "Red Button",
                modifier = Modifier
                    .size(50.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-40).dp, y = (-150).dp)
                    .clickable { }
            )
        }
    }

    @Composable
    fun Player1RadioConfirmationScreen(
        onBackClick: () -> Unit,
        onNextClick: () -> Unit
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(300.dp)
                    .height(250.dp)
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceAround
            ) {
                Text(
                    text = "Are you sure Player 1 got the golden key?",
                    color = Color.Black,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onBackClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Back", color = Color.Black, fontSize = 18.sp)
                    }

                    Button(
                        onClick = onNextClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .padding(horizontal = 8.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Next", color = Color.Black, fontSize = 18.sp)
                    }
                }
            }

            Image(
                painter = painterResource(id = R.drawable.redbutton),
                contentDescription = "Red Button",
                modifier = Modifier
                    .size(50.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-40).dp, y = (-80).dp)
                    .clickable { }
            )
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///screen previews//
    @Preview(showBackground = true)
    @Composable
    fun PreviewMainMenuScreen() {
        MainMenu(onPlayer1Click = {}, onPlayer2Click = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer1Screen() {
        Player1Screen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer1InfoScreen() {
        Player1InfoScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer1CommunicationScreen() {
        Player1CommunicationScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer2TrustScreen() {
        Player2TrustScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewGameStartScreen() {
        GameStartScreen(onBackClick = {}, onStartClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer2Screen() {
        Player2Screen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer2InfoScreen() {
        Player2InfoScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer2CommunicationScreen() {
        Player2CommunicationScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer1TrustScreen() {
        Player1TrustScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewSliderGameScreenP1() {
        SliderGameScreen(isPlayer2 = false, onButtonClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewSliderGameScreenP2() {
        SliderGameScreen(isPlayer2 = true, onButtonClick = {})
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewHorizontalSlider() {
        HorizontalSlider(modifier = Modifier.width(300.dp))
    }

    @Preview(showBackground = true)
    @Composable
    fun PreviewPlayer2ConfirmationScreen() {
        Player2ConfirmationScreen(onBackClick = {}, onNextClick = {})
    }

    @Preview(showBackground = true, widthDp = 360, heightDp = 640)
    @Composable
    fun PreviewPlayer1RadioConfirmationScreen() {
        Player1RadioConfirmationScreen(onBackClick = {}, onNextClick = {})
    }
}