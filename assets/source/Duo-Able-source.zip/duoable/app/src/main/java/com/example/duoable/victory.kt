package com.example.duoable

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.util.Log

@Composable
fun VictoryScreen(
    onNext2Click: () -> Unit,
    onRecordTimeClick: () -> Unit,
    gameTime: String = "00:00:00"
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Image(
            painter = painterResource(id = R.drawable.victory),
            contentDescription = "Victory Trophy",
            modifier = Modifier
                .size(width = 300.dp, height = 330.dp)
                .align(Alignment.TopCenter)
                .offset(y = 100.dp)
        )

        Text(
            text = "Time: $gameTime",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = 460.dp)
        )

        Image(
            painter = painterResource(id = R.drawable.next2),
            contentDescription = "Next Button",
            modifier = Modifier
                .size(width = 110.dp, height = 50.dp)
                .align(Alignment.TopCenter)
                .offset(x = 70.dp, y = (520).dp)
                .clickable {
                    Log.d("VictoryScreen", "Next2 Button Clicked!")
                    onNext2Click()
                }
        )

        Image(
            painter = painterResource(id = R.drawable.recordtime),
            contentDescription = "Record Time Button",
            modifier = Modifier
                .size(width = 130.dp, height = 50.dp)
                .align(Alignment.TopCenter)
                .offset(x = -70.dp, y = (520).dp)
                .clickable {
                    Log.d("VictoryScreen", "Record Time Button Clicked!")
                    onRecordTimeClick()
                }
        )
    }
}

@Composable
fun ThanksScreen(
    onSuggestClick: () -> Unit,
    onPlayAgainClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Image(
            painter = painterResource(id = R.drawable.thanks),
            contentDescription = "Thank You Screen Content",
            modifier = Modifier
                .size(width = 280.dp, height = 320.dp)
                .align(Alignment.Center)
                .offset(y = 0.dp)
        )

        Image(
            painter = painterResource(id = R.drawable.suggest),
            contentDescription = "Suggest Button",
            modifier = Modifier
                .size(width = 110.dp, height = 50.dp)
                .align(Alignment.Center)
                .offset(x = (-60).dp, y = 110.dp)
                .clickable {
                    Log.d("ThanksScreen", "Suggest Button Clicked!")
                    onSuggestClick()
                }
        )

        Image(
            painter = painterResource(id = R.drawable.playagain),
            contentDescription = "Play Again Button",
            modifier = Modifier
                .size(width = 110.dp, height = 50.dp)
                .align(Alignment.Center)
                .offset(x = 60.dp, y = 110.dp)
                .clickable {
                    Log.d("ThanksScreen", "Play Again Button Clicked!")
                    onPlayAgainClick()
                }
        )
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 640)
@Composable
fun PreviewThanksScreen() {
    ThanksScreen(
        onSuggestClick = { },
        onPlayAgainClick = { }
    )
}

@Preview(showBackground = true, widthDp = 360, heightDp = 640)
@Composable
fun PreviewVictoryScreen() {
    VictoryScreen(
        onNext2Click = { },
        onRecordTimeClick = { },
        gameTime = "01:23:45"
    )
}
