package com.example.duoable
import androidx.compose.ui.unit.sp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextField
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.runtime.remember


@Composable
fun Round3Player2(onButtonClick: () -> Unit) {
    val buttons = listOf(
        "Him", "Her", "They",
        "Everybody", "He", "Everyone",
        "Anybody", "Someone", "She",
        "Somebody", "Anyone"
    )

    val sentenceMap = mapOf(
        "Her" to "That french guy telling that her wife only knows it but her sister April, knows where his wife is.",
        "Him" to "Rem knows a little about the rumor.",
        "He" to "May is not a witch.",
        "They" to "Liza is Josh's Brother.",
        "Everyone" to "Terry right before his death, saw his two bestfriend. Torry and Oliver.",
        "Everybody" to "Josh knows anything and anyone may tell lies.",
        "Anyone" to "Ben is the real culprit.",
        "Someone" to "That someone is a witch, Dolly.",
        "Anybody" to "Ben is not the culprit",
        "She" to "The witch isn't really scary",
        "Somebody" to "Rem is the leader of the bandits."
    )
    val showDialog = remember { mutableStateOf(false) }
    val currentMessage = remember { mutableStateOf("..........") }
    val selectedLabel = remember { mutableStateOf<String?>(null) }
    var inputText by remember { mutableStateOf("") }


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black) // 🟣 BLACK BACKGROUND
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Button Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.height(220.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(buttons.size) { index ->
                    val label = buttons[index]
                    val isSelected = selectedLabel.value == label
                    Button(
                        onClick = {
                            selectedLabel.value = buttons[index]
                            currentMessage.value = sentenceMap[buttons[index]] ?: ".........."
                        },
                        modifier = Modifier.fillMaxWidth()
                            .width(100.dp)
                            .height(48.dp)
                            .border(1.dp, Color.White, shape = RoundedCornerShape(8.dp)),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) Color.White else Color.Black,
                            contentColor = if (isSelected) Color.Black else Color.White,
                        ),


                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(buttons[index])
                    }
                }
            }



            // DISPLAY TO
            Box(
                modifier = Modifier
                    .width(250.dp)
                    .height(200.dp)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = currentMessage.value,
                    color = Color.White)
            }

            // Big Red Button
            Button(
                onClick = { showDialog.value = true },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                modifier = Modifier
                    .size(60.dp)
                    .border(2.dp, Color.White, CircleShape)
            ) {}

            if (showDialog.value) {
                AlertDialog(
                    onDismissRequest = { showDialog.value = false },
                    text = {
                        Column {
                            Text(
                                buildAnnotatedString {
                                    append("Are you sure Player 1 got the ")
                                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                                        append("Golden Key")
                                    }
                                    append("?")
                                }
                            )

                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            showDialog.value = false
                            onButtonClick()
                        },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Black,
                                contentColor = Color.White
                            ))
                        {
                            Text("Next")
                        }
                    },
                    dismissButton = {
                        Button(onClick = { showDialog.value = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Black,
                                contentColor = Color.White
                            ) ) {
                            Text("Cancel")
                        }
                    }
                )
            }

        }
    }
}



@Composable
fun Round3Player1(onButtonClick: () -> Unit) {
    val rightOrder = listOf("Terry", "Dolly", "Torry", "Oliver", "May", "Josh", "Ben")
    val buttons = listOf(
        "Terry", "Jude", "May",
        "Liza", "Ben", "Torry",
        "Josh", "Theo", "Oliver",
        "Rem", "Dolly"
    )
    var showCulpritQuestion by remember { mutableStateOf(false) }
    var culpritMessage by remember { mutableStateOf("") }

    var progress by remember { mutableStateOf(0) }
    val clickedNames = remember { mutableStateListOf<String>() }
    val selectedLabel = remember { mutableStateOf<String?>(null) }
    val showDialog = remember { mutableStateOf(false) }

    val fullStory = listOf(
        "Terry is at someone’s house.",
        "No one knows if that house is abandoned or not. So his friend told Terry to go inspect it, it wouldn’t be trespassing either if the house is considered abandoned right? Oh dear boy, poor Terry. He was surprised by those bandits. It was a trap! He was mugged and took his life.",

        "According to the investigation, the bandits only took advantage of the abandoned house. One of them was caught and doesn’t say nothing but hers.  ",
        "",
        "Everybody on the village have rumors that  anyone who tries to visit the abandoned house, worse will happen. The investigation is still ongoing. ",

    )

    val sentenceTriggers = listOf(
        "Terry",
        "Terry",
        "Dolly",
        "Torry",
        "Oliver",
        "May",
        "Josh"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.height(220.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(buttons.size) { index ->
                    val label = buttons[index]

                    val isCorrectlyClicked = clickedNames.contains(label)
                    Button(
                        onClick = {
                            selectedLabel.value = label
                            if (label == rightOrder.getOrNull(progress)) {
                                if (!clickedNames.contains(label)) {
                                    clickedNames.add(label)
                                    progress += 1

                                    if (label == "Josh") {
                                        showCulpritQuestion = true
                                    }
                                }
                            } else if (showCulpritQuestion && label == "Ben") {
                                culpritMessage = "Nice catch!"
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .width(100.dp)
                            .height(48.dp)
                            .border(1.dp, Color.White, shape = RoundedCornerShape(8.dp)),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCorrectlyClicked) Color.White else Color.Black,
                            contentColor = if (isCorrectlyClicked) Color.Black else Color.White,
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(label)
                    }
                }
            }

            // PROGRESS DOTS
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 24.dp)
            ) {
                for (i in 0 until 7) {
                    val isFilled = i < progress
                    Box(
                        modifier = Modifier
                            .width(30.dp)
                            .height(5.dp)
                            .background(
                                color = if (isFilled) Color.White else Color.Black,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, Color.White, RoundedCornerShape(4.dp))
                    )
                }
            }

            val annotatedText = buildAnnotatedString {
                fullStory.forEachIndexed { index, sentence ->
                    val trigger = sentenceTriggers.getOrNull(index)
                    val isVisible = when {
                        index == 0 -> true
                        trigger == "Terry" && clickedNames.contains("Terry") -> true
                        trigger != null && clickedNames.contains(trigger) -> true
                        else -> false
                    }

                    withStyle(
                        style = SpanStyle(
                            color = if (isVisible) Color.White else Color.Gray,
                            fontWeight = if (isVisible) FontWeight.Bold else FontWeight.Normal
                        )
                    ) {
                        append(sentence)
                        append(" ")
                    }
                }
            }



            Box(
                modifier = Modifier
                    .width(330.dp)
                    .height(250.dp)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = annotatedText,
                    textAlign = TextAlign.Center
                )
            }
            if (showCulpritQuestion) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text(
                        text = "Who is the real culprit?",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    if (culpritMessage.isNotEmpty()) {
                        Text(
                            text = culpritMessage,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }


            // RED BUTTON
            Button(
                onClick = {
                    if (progress == 7) {
                        onButtonClick()
                    }
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = if (progress == 7) Color.Red else Color.Gray),
                modifier = Modifier
                    .size(60.dp)
                    .border(2.dp, Color.White, CircleShape)
            ) {}



        }
    }
}


