﻿using Android.App;
using Android.OS;
using Android.Runtime;
using Android.Widget;
using AndroidX.AppCompat.App;
using System;
using System.Timers;

namespace Face_Change_App
{
    [Activity(Label = "Face Changing App", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        ImageView iv;
        Button rollbtn, startbtn;
        ImageButton[] faceButtons;
        Timer timer;
        FaceManager faceManager;
        bool isRolling = false;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_main);

            faceManager = new FaceManager(Resources, PackageName);

            iv = FindViewById<ImageView>(Resource.Id.imageView1);
            rollbtn = FindViewById<Button>(Resource.Id.button1);
            startbtn = FindViewById<Button>(Resource.Id.button2);

            faceButtons = new ImageButton[]
            {
                FindViewById<ImageButton>(Resource.Id.imageButton1),
                FindViewById<ImageButton>(Resource.Id.imageButton2),
                FindViewById<ImageButton>(Resource.Id.imageButton3),
                FindViewById<ImageButton>(Resource.Id.imageButton4)
            };

            SetWholePic();

            timer = new Timer { Interval = 100 };
            timer.Elapsed += Timer_Elapsed;

            rollbtn.Click += RollButton_Click;
            startbtn.Click += StartButton_Click;

            for (int i = 0; i < faceButtons.Length; i++)
            {
                int buttonIndex = i;
                faceButtons[i].Click += (s, e) =>
                {
                    int resId = faceManager.GetFacePartResourceId(buttonIndex);
                    faceButtons[buttonIndex].SetImageResource(resId != 0 ? resId : Android.Resource.Drawable.IcDelete);
                };
            }
        }

        private void RollButton_Click(object sender, EventArgs e)
        {
            if (!isRolling)
            {
                timer.Start();
                isRolling = true;
                rollbtn.Text = "Stop";
            }
            else
            {
                timer.Stop();
                isRolling = false;
                rollbtn.Text = "Roll";
            }
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            int[] partIds = faceManager.GetRandomParts();
            for (int i = 0; i < faceButtons.Length; i++)
            {
                faceButtons[i].SetImageResource(partIds[i] != 0 ? partIds[i] : Android.Resource.Drawable.IcDelete);
            }
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            faceManager.RollNewFace();
            RunOnUiThread(SetWholePic);
        }

        private void SetWholePic()
        {
            int resId = faceManager.GetWholeFaceResourceId();
            iv.SetImageResource(resId);
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
